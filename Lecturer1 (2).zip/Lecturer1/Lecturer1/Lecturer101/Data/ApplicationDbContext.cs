﻿using Lecturer101.Areas.Identity.Data;
using Lecturer101.Models.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Lecturer101.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // Your custom model configuration here
        }


    public DbSet<Lecturer> Lecturers { get; set; }
        public DbSet<Manager> Managers { get; set; }
        public DbSet<PayClaim> PayClaims { get; set; }
    }


}
    

