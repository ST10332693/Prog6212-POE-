using Lecturer101.Areas.Identity.Data;
using Lecturer101.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Configure the connection string for your application's DbContext.
var connectionString = builder.Configuration.GetConnectionString("Lecturer101ContextConnection")
                       ?? throw new InvalidOperationException("Connection string 'Lecturer101ContextConnection' not found.");

// Register your application's main DbContext (for Lecturer, PayClaim, etc.)
builder.Services.AddDbContext<Lecturer101Context>(options =>
    options.UseSqlServer(connectionString));

// Register the Identity DbContext for authentication and user management.
builder.Services.AddDbContext<Lecturer101Context>(options =>
    options.UseSqlServer(connectionString));

// Configure Identity services for authentication and authorization.
builder.Services.AddIdentity<Lecturer101User, IdentityRole>()
    .AddEntityFrameworkStores<Lecturer101.Areas.Identity.Data.Lecturer101Context>()
    .AddDefaultUI()
    .AddDefaultTokenProviders();

// Add services for controllers and views.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Add middleware for authentication and authorization.
app.UseAuthentication();
app.UseAuthorization();

// Configure the route mappings.
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapRazorPages();

app.Run();
