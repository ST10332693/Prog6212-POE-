﻿using Lecturer101.Models.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Lecturer101.Areas.Identity.Data
{
    public class Lecturer101Context(DbContextOptions<Lecturer101Context> options) : IdentityDbContext<Lecturer101User>(options)
    {
        public DbSet<Lecturer> Lecturers { get; set; }
        public DbSet<Manager> Managers { get; set; }
        public DbSet<PayClaim> PayClaims { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure Lecturer
            builder.Entity<Lecturer>()
                .HasKey(l => l.Id); // Ensure a primary key for Lecturer

            // Configure Manager
            builder.Entity<Manager>()
                .HasKey(m => m.Id); // Ensure a primary key for Manager

            // Configure the relationship between PayClaim and Lecturer
            builder.Entity<PayClaim>()
                .HasOne(p => p.Lecturer)
                .WithMany(l => l.PayClaims)
                .HasForeignKey(p => p.LecturerId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure the relationship between PayClaim and Manager
            builder.Entity<PayClaim>()
                .HasOne(p => p.Manager)
                .WithMany(m => m.PayClaimsToApprove)
                .HasForeignKey(p => p.ManagerId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
