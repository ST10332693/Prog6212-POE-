﻿using Lecturer101.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;


namespace Lecturer101.Migrations.ApplicationDb
{
   
    public class ApplicationDbContextFactory : IDesignTimeDbContextFactory<ApplicationDbContext>
    {
        public ApplicationDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            optionsBuilder.UseSqlServer("Your_Connection_String_Here");

            return new ApplicationDbContext(optionsBuilder.Options);
        }
    }

}
