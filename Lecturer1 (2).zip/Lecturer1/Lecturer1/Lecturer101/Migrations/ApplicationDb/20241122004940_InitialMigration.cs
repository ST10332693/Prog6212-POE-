﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Lecturer101.Migrations.ApplicationDb
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PayClaims_Lecturers_LecturerId",
                table: "PayClaims");

            migrationBuilder.DropForeignKey(
                name: "FK_PayClaims_Managers_ManagerId",
                table: "PayClaims");

            migrationBuilder.AddForeignKey(
                name: "FK_PayClaims_Lecturers_LecturerId",
                table: "PayClaims",
                column: "LecturerId",
                principalTable: "Lecturers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_PayClaims_Managers_ManagerId",
                table: "PayClaims",
                column: "ManagerId",
                principalTable: "Managers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PayClaims_Lecturers_LecturerId",
                table: "PayClaims");

            migrationBuilder.DropForeignKey(
                name: "FK_PayClaims_Managers_ManagerId",
                table: "PayClaims");

            migrationBuilder.AddForeignKey(
                name: "FK_PayClaims_Lecturers_LecturerId",
                table: "PayClaims",
                column: "LecturerId",
                principalTable: "Lecturers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PayClaims_Managers_ManagerId",
                table: "PayClaims",
                column: "ManagerId",
                principalTable: "Managers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
