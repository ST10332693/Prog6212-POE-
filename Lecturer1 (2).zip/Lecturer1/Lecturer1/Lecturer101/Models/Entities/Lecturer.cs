﻿namespace Lecturer101.Models.Entities
{
    public class Lecturer
    {
        public int Id { get; set; }
        public required string Name { get; set; }  // Lecturer's name
        public required string Email { get; set; } // Lecturer's email

        // Navigation property to related pay claims
        public required ICollection<PayClaim> PayClaims { get; set; }
    }

}