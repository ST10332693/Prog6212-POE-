﻿namespace Lecturer101.Models.Entities
{
    public class PayClaim
    {
        public int Id { get; set; }
        public int LecturerId { get; set; }  // Foreign key to Lecturer
        public int ManagerId { get; set; }   // Foreign key to Manager
        public decimal Amount { get; set; }  // The amount the lecturer is claiming
        public DateTime DateClaimed { get; set; }  // Date of the claim
        public required string Status { get; set; }  // "Pending", "Approved", "Rejected"

        // Navigation properties
        public required Lecturer? Lecturer { get; set; }
        public required Manager? Manager { get; set; }
    }

}
