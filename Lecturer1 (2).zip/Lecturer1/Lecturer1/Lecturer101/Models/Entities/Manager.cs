﻿namespace Lecturer101.Models.Entities
{
    public class Manager
    {
        public int Id { get; set; }
        public required string Name { get; set; }  // Manager's name
        public required string Email { get; set; } // Manager's email

        // Navigation property to the pay claims they approve/reject
        public required ICollection<PayClaim> PayClaimsToApprove { get; set; }
    }

}