﻿using Lecturer101.Areas.Identity.Data;
using Lecturer101.Models.Entities;      // For PayClaim, Lecturer models
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Linq;

namespace Lecturer101.Controllers
{
    public class LecturerController : Controller
    {
        private readonly Lecturer101Context _context;
        private readonly Manager? _manager; // Make manager nullable

        public LecturerController(Lecturer101Context context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));

            // Initialize the manager field (set to null if not found)
            _manager = _context.Managers.FirstOrDefault(); // Replace with actual logic
        }

        // GET: Lecturer/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Lecturer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Lecturer lecturer)
        {
            if (ModelState.IsValid)
            {
                _context.Lecturers.Add(lecturer);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Lecturer created successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(lecturer);
        }

        // GET: Lecturer/Details/5
        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var lecturer = await _context.Lecturers
                .Include(l => l.PayClaims) // Include pay claims to show on the details page
                .FirstOrDefaultAsync(l => l.Id == id);

            if (lecturer == null)
            {
                return NotFound();
            }

            return View(lecturer);
        }

        // GET: Lecturer/Index
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var lecturers = await _context.Lecturers.ToListAsync();
            return View(lecturers);
        }

        // GET: Lecturer/Delete/5
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var lecturer = _context.Lecturers.FirstOrDefault(l => l.Id == id);
            if (lecturer == null)
            {
                return NotFound();
            }
            return View(lecturer);
        }

        // POST: Lecturer/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var lecturer = await _context.Lecturers.FindAsync(id);
            if (lecturer != null)
            {
                _context.Lecturers.Remove(lecturer);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: Lecturer/LecturerClaims
        [HttpGet]
        public async Task<IActionResult> LecturerClaims()
        {
            var lecturerClaims = await _context.Lecturers
                .Include(l => l.PayClaims)
                .ToListAsync();

            return View(lecturerClaims);
        }

        // POST: Lecturer/LecturerClaims
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LecturerClaims(string status)
        {
            var lecturerClaims = await _context.Lecturers
                .Include(l => l.PayClaims)
                .Where(l => l.PayClaims.Any(c => c.Status == status))
                .ToListAsync();

            return View(lecturerClaims);
        }

        // GET: Lecturer/CreatePayClaim
        [HttpGet]
        public IActionResult CreatePayClaim()
        {
            return View();
        }

        // POST: Lecturer/CreatePayClaim
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreatePayClaim(decimal amount)
        {
            var lecturerId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var lecturer = await _context.Lecturers
                .FirstOrDefaultAsync(l => l.Email == lecturerId);

            if (lecturer == null)
            {
                return NotFound("Lecturer not found.");
            }

            var payClaim = new PayClaim
            {
                LecturerId = lecturer.Id,
                Amount = amount,
                DateClaimed = DateTime.Now,
                Status = "Pending",
                Lecturer = lecturer,
                Manager = _manager // Use the nullable manager
            };

            _context.PayClaims.Add(payClaim);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Pay claim has been successfully created.";
            return RedirectToAction(nameof(Index));
        }

        // Test action for verification
        [HttpGet]
        public IActionResult Test()
        {
            return Content("Test action works");
        }
    }
}
