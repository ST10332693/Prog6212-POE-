﻿using Lecturer101.Areas.Identity.Data;
using Lecturer101.Models.Entities;  // Make sure this includes PayClaim, Lecturer, and Manager
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Linq;

namespace Lecturer101.Controllers
{
    public class ManagerController : Controller
    {
        private readonly Lecturer101Context _context;

        public ManagerController(Lecturer101Context context)
        {
            _context = context;  // Inject the specific DbContext
        }

        // GET: ViewPendingClaims
        public async Task<IActionResult> ViewPendingClaims()
        {
            var pendingClaims = await _context.PayClaims
                .Where(pc => pc.Status == "Pending")
                .Include(pc => pc.Lecturer)  // Include Lecturer information
                .Include(pc => pc.Manager)   // Include Manager information
                .ToListAsync();

            return View(pendingClaims);  // Return the pending claims to the view
        }

        // GET: Manager/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Manager/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Manager manager)
        {
            if (ModelState.IsValid)
            {
                _context.Managers.Add(manager);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Manager created successfully!";
                return RedirectToAction(nameof(Index));
            }

            return View(manager);
        }

        // Optionally, create an Index method to view all managers
        public async Task<IActionResult> Index()
        {
            var managers = await _context.Managers.ToListAsync();
            return View(managers);
        }

        // POST: ApproveClaim
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveClaim(int claimId)
        {
            var payClaim = await _context.PayClaims.FindAsync(claimId);

            if (payClaim == null)
            {
                return NotFound("Claim not found.");
            }

            var currentManagerIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);  // Assuming Manager is logged in
            if (int.TryParse(currentManagerIdString, out int currentManagerId) && payClaim.ManagerId != currentManagerId)
            {
                return Unauthorized("You do not have permission to approve this claim.");
            }

            payClaim.Status = "Approved";
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Claim has been approved successfully.";
            return RedirectToAction("ViewPendingClaims");
        }

        // GET: Manager/Details/5
        public IActionResult Details(int id)
        {
            var manager = _context.Managers.FirstOrDefault(m => m.Id == id);
            if (manager == null)
            {
                return NotFound();
            }
            return View(manager);  // Pass the manager object to the view
        }

        // GET: Manager/Edit/5
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var manager = _context.Managers.FirstOrDefault(m => m.Id == id);
            if (manager == null)
            {
                return NotFound();
            }
            return View(manager);
        }

        // POST: Manager/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Email")] Manager manager)
        {
            if (id != manager.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(manager);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ManagerExists(manager.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(manager);
        }

        // GET: Manager/Delete/5
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var manager = _context.Managers.FirstOrDefault(m => m.Id == id);
            if (manager == null)
            {
                return NotFound();
            }
            return View(manager);  // Pass the manager object to the view
        }

        // POST: Manager/Delete/5 (Perform the deletion)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var manager = _context.Managers.FirstOrDefault(m => m.Id == id);
            if (manager == null)
            {
                return NotFound();
            }

            _context.Managers.Remove(manager);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));  // Redirect to the index page after deletion
        }

        // POST: RejectClaim
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RejectClaim(int claimId)
        {
            var payClaim = await _context.PayClaims.FindAsync(claimId);

            if (payClaim == null)
            {
                return NotFound("Claim not found.");
            }

            var currentManagerIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);  // Assuming Manager is logged in
            if (int.TryParse(currentManagerIdString, out int currentManagerId) && payClaim.ManagerId != currentManagerId)
            {
                return Unauthorized("You do not have permission to reject this claim.");
            }

            payClaim.Status = "Rejected";
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Claim has been rejected.";
            return RedirectToAction("ViewPendingClaims");
        }

        private bool ManagerExists(int id)
        {
            return _context.Managers.Any(e => e.Id == id);
        }
    }
}

